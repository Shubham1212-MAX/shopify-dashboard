'use client'

import { useState, useEffect } from 'react'
import { Package, RefreshCw, Ship, Filter, Search, X } from 'lucide-react'

interface Order {
  id: number
  order_number: string
  customer_name: string
  total_price: number
  status: string
  can_ship: boolean
  line_items: any[]
  shipping_address: any
  payment_method: string
  shiprocket_account: number | null
  created_at: string
}

interface InventoryItem {
  id: number
  sku: string
  product_name: string
  variant_title: string
  quantity: number
  color: string
  size: string
}

export default function Home() {
  const [orders, setOrders] = useState<Order[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [loading, setLoading] = useState(true)
  const [syncing, setSyncing] = useState(false)
  const [selectedOrders, setSelectedOrders] = useState<number[]>([])
  const [showSidebar, setShowSidebar] = useState(false)
  const [filterStatus, setFilterStatus] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  // New inventory form
  const [newInventory, setNewInventory] = useState({
    sku: '',
    product_name: '',
    color: '',
    size: '',
    quantity: 0,
  })

  useEffect(() => {
    fetchOrders()
    fetchInventory()
  }, [])

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders')
      const data = await res.json()
      setOrders(data.orders || [])
    } catch (error) {
      console.error('Error fetching orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchInventory = async () => {
    try {
      const res = await fetch('/api/inventory')
      const data = await res.json()
      setInventory(data.inventory || [])
    } catch (error) {
      console.error('Error fetching inventory:', error)
    }
  }

  const syncOrders = async () => {
    setSyncing(true)
    try {
      await fetch('/api/sync-orders', { method: 'POST' })
      await fetchOrders()
      alert('✅ Orders synced successfully!')
    } catch (error) {
      alert('❌ Error syncing orders')
    } finally {
      setSyncing(false)
    }
  }

  const addInventory = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const res = await fetch('/api/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newInventory),
      })
      if (res.ok) {
        await fetchInventory()
        await fetchOrders() // Refresh to update can_ship status
        setNewInventory({ sku: '', product_name: '', color: '', size: '', quantity: 0 })
        alert('✅ Inventory added!')
      }
    } catch (error) {
      alert('❌ Error adding inventory')
    }
  }

  const bulkShip = async () => {
    if (selectedOrders.length === 0) {
      alert('Please select orders to ship')
      return
    }

    try {
      const res = await fetch('/api/ship-orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderIds: selectedOrders }),
      })
      if (res.ok) {
        alert(`✅ ${selectedOrders.length} orders shipped!`)
        setSelectedOrders([])
        await fetchOrders()
      }
    } catch (error) {
      alert('❌ Error shipping orders')
    }
  }

  const toggleOrderSelection = (orderId: number) => {
    setSelectedOrders((prev) =>
      prev.includes(orderId) ? prev.filter((id) => id !== orderId) : [...prev, orderId]
    )
  }

  const filteredOrders = orders
    .filter((order) => (filterStatus === 'all' ? true : order.status === filterStatus))
    .filter((order) =>
      searchQuery
        ? order.order_number.includes(searchQuery) ||
          order.customer_name.toLowerCase().includes(searchQuery.toLowerCase())
        : true
    )

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">📦 Shopify Dashboard</h1>
          <div className="flex gap-3">
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center gap-2"
            >
              <Package size={18} />
              Inventory
            </button>
            <button
              onClick={syncOrders}
              disabled={syncing}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 disabled:opacity-50"
            >
              <RefreshCw size={18} className={syncing ? 'animate-spin' : ''} />
              Sync Orders
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-4">
        {/* Main Content */}
        <div className="flex-1">
          {/* Filters */}
          <div className="bg-white p-4 rounded-lg shadow-md mb-4">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search orders..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="fulfilled">Fulfilled</option>
                <option value="paid">Paid</option>
                <option value="unfulfilled">Unfulfilled</option>
              </select>
            </div>
          </div>

          {/* Bulk Actions */}
          {selectedOrders.length > 0 && (
            <div className="bg-blue-100 p-4 rounded-lg shadow-md mb-4 flex justify-between items-center">
              <p className="text-blue-800 font-semibold">{selectedOrders.length} orders selected</p>
              <button
                onClick={bulkShip}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
              >
                <Ship size={18} />
                Ship Selected
              </button>
            </div>
          )}

          {/* Orders Table */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3 text-left">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedOrders(filteredOrders.map((o) => o.id))
                        } else {
                          setSelectedOrders([])
                        }
                      }}
                    />
                  </th>
                  <th className="p-3 text-left">Order #</th>
                  <th className="p-3 text-left">Customer</th>
                  <th className="p-3 text-left">Amount</th>
                  <th className="p-3 text-left">Status</th>
                  <th className="p-3 text-left">Ship Status</th>
                  <th className="p-3 text-left">Payment</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-gray-500">
                      Loading orders...
                    </td>
                  </tr>
                ) : filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-gray-500">
                      No orders found
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => (
                    <tr
                      key={order.id}
                      className={`border-t hover:bg-gray-50 ${
                        order.can_ship ? 'bg-green-50' : ''
                      }`}
                    >
                      <td className="p-3">
                        <input
                          type="checkbox"
                          checked={selectedOrders.includes(order.id)}
                          onChange={() => toggleOrderSelection(order.id)}
                        />
                      </td>
                      <td className="p-3 font-semibold">#{order.order_number}</td>
                      <td className="p-3">{order.customer_name}</td>
                      <td className="p-3">₹{order.total_price.toFixed(2)}</td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            order.status === 'fulfilled'
                              ? 'bg-green-100 text-green-800'
                              : order.status === 'paid'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="p-3">
                        {order.can_ship ? (
                          <span className="text-green-600 font-semibold">✅ Can Ship</span>
                        ) : (
                          <span className="text-gray-400">⏳ Waiting Stock</span>
                        )}
                      </td>
                      <td className="p-3 text-sm text-gray-600">{order.payment_method}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Inventory Sidebar */}
        {showSidebar && (
          <div className="w-80 bg-white rounded-lg shadow-md p-4 h-fit sticky top-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800">📦 Inventory</h2>
              <button onClick={() => setShowSidebar(false)}>
                <X size={20} />
              </button>
            </div>

            {/* Add Inventory Form */}
            <form onSubmit={addInventory} className="mb-6 space-y-3">
              <input
                type="text"
                placeholder="SKU"
                value={newInventory.sku}
                onChange={(e) => setNewInventory({ ...newInventory, sku: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                required
              />
              <input
                type="text"
                placeholder="Product Name"
                value={newInventory.product_name}
                onChange={(e) => setNewInventory({ ...newInventory, product_name: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                required
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Color"
                  value={newInventory.color}
                  onChange={(e) => setNewInventory({ ...newInventory, color: e.target.value })}
                  className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <input
                  type="text"
                  placeholder="Size"
                  value={newInventory.size}
                  onChange={(e) => setNewInventory({ ...newInventory, size: e.target.value })}
                  className="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <input
                type="number"
                placeholder="Quantity"
                value={newInventory.quantity}
                onChange={(e) =>
                  setNewInventory({ ...newInventory, quantity: parseInt(e.target.value) || 0 })
                }
                className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                required
              />
              <button
                type="submit"
                className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
              >
                Add Stock
              </button>
            </form>

            {/* Inventory List */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              <h3 className="font-semibold text-gray-700 mb-2">Current Stock:</h3>
              {inventory.map((item) => (
                <div key={item.id} className="p-3 bg-gray-50 rounded-lg border">
                  <p className="font-semibold text-sm">{item.product_name}</p>
                  <p className="text-xs text-gray-600">
                    {item.color} • {item.size} • SKU: {item.sku}
                  </p>
                  <p className="text-sm font-bold text-purple-600 mt-1">Qty: {item.quantity}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
