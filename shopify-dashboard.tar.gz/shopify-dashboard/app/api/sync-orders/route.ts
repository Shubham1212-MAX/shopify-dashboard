import { NextResponse } from 'next/server'
import supabase from '@/lib/supabase'
import axios from 'axios'

export const dynamic = 'force-dynamic'

interface ShopifyOrder {
  id: number
  order_number: string
  customer?: {
    first_name?: string
    last_name?: string
    email?: string
  }
  total_price: string
  financial_status: string
  fulfillment_status: string | null
  line_items: any[]
  shipping_address: any
  payment_gateway_names: string[]
  created_at: string
}

export async function POST(request: Request) {
  try {
    console.log('🔄 Starting order sync...')

    // Get all Shopify stores configuration
    const stores = [
      {
        id: 1,
        name: 'Store 1',
        url: process.env.SHOPIFY_STORE_1_URL,
        token: process.env.SHOPIFY_STORE_1_TOKEN,
      },
      {
        id: 2,
        name: 'Store 2',
        url: process.env.SHOPIFY_STORE_2_URL,
        token: process.env.SHOPIFY_STORE_2_TOKEN,
      },
      {
        id: 3,
        name: 'Store 3',
        url: process.env.SHOPIFY_STORE_3_URL,
        token: process.env.SHOPIFY_STORE_3_TOKEN,
      },
    ]

    let totalOrders = 0

    // First, ensure stores are in database
    for (const store of stores) {
      if (!store.url || !store.token) continue

      const { error: storeError } = await supabase
        .from('stores')
        .upsert({
          id: store.id,
          name: store.name,
          shopify_url: store.url,
          access_token: store.token,
        })

      if (storeError) {
        console.error(`Error upserting store ${store.name}:`, storeError)
      }
    }

    // Sync orders from each store
    for (const store of stores) {
      if (!store.url || !store.token) {
        console.log(`⚠️ Skipping ${store.name} - missing credentials`)
        continue
      }

      try {
        console.log(`📦 Fetching orders from ${store.name}...`)

        // Fetch orders from Shopify
        const response = await axios.get(
          `https://${store.url}/admin/api/2024-01/orders.json`,
          {
            headers: {
              'X-Shopify-Access-Token': store.token,
            },
            params: {
              status: 'any',
              limit: 250,
            },
          }
        )

        const orders: ShopifyOrder[] = response.data.orders || []
        console.log(`✅ Found ${orders.length} orders from ${store.name}`)

        // Process each order
        for (const order of orders) {
          const customerName = order.customer
            ? `${order.customer.first_name || ''} ${order.customer.last_name || ''}`.trim()
            : 'Unknown'

          const status = order.fulfillment_status || order.financial_status || 'pending'

          // Get payment method
          const paymentMethod =
            order.payment_gateway_names && order.payment_gateway_names.length > 0
              ? order.payment_gateway_names[0]
              : 'Unknown'

          // Check if SKU mapping exists for Shiprocket account routing
          let shiprocketAccount = null
          if (order.line_items && order.line_items.length > 0) {
            const firstSku = order.line_items[0].sku
            if (firstSku) {
              const { data: mapping } = await supabase
                .from('sku_mapping')
                .select('shiprocket_account')
                .eq('sku', firstSku)
                .single()

              if (mapping) {
                shiprocketAccount = mapping.shiprocket_account
              }
            }
          }

          // Insert or update order
          const { error: orderError } = await supabase.from('orders').upsert({
            store_id: store.id,
            shopify_order_id: order.id.toString(),
            order_number: order.order_number.toString(),
            customer_name: customerName,
            customer_email: order.customer?.email || null,
            total_price: parseFloat(order.total_price),
            status: status,
            line_items: order.line_items,
            shipping_address: order.shipping_address,
            payment_method: paymentMethod,
            shiprocket_account: shiprocketAccount,
            can_ship: false, // Will be updated by inventory check
            updated_at: new Date().toISOString(),
          })

          if (orderError) {
            console.error(`Error upserting order ${order.order_number}:`, orderError)
          } else {
            totalOrders++
          }
        }
      } catch (error: any) {
        console.error(`❌ Error syncing ${store.name}:`, error.message)
      }
    }

    console.log(`✅ Sync completed! Total orders synced: ${totalOrders}`)

    return NextResponse.json({
      success: true,
      message: `Synced ${totalOrders} orders successfully`,
      totalOrders,
    })
  } catch (error: any) {
    console.error('❌ Sync error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    )
  }
}

export async function GET(request: Request) {
  return POST(request)
}
