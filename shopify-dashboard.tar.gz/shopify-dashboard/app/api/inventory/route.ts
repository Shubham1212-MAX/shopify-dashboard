import { NextResponse } from 'next/server'
import supabase from '@/lib/supabase'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const { data: inventory, error } = await supabase
      .from('inventory')
      .select('*')
      .order('updated_at', { ascending: false })

    if (error) {
      throw error
    }

    return NextResponse.json({
      success: true,
      inventory: inventory || [],
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { sku, product_name, color, size, quantity } = body

    // Add or update inventory
    const { data, error } = await supabase
      .from('inventory')
      .upsert(
        {
          sku,
          product_name,
          variant_title: `${color} ${size}`.trim(),
          color,
          size,
          quantity,
          updated_at: new Date().toISOString(),
        },
        {
          onConflict: 'sku',
        }
      )
      .select()

    if (error) {
      throw error
    }

    // Update orders can_ship status based on inventory
    await updateOrdersShippability()

    return NextResponse.json({
      success: true,
      inventory: data,
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    )
  }
}

async function updateOrdersShippability() {
  try {
    // Get all orders and inventory
    const { data: orders } = await supabase.from('orders').select('*')
    const { data: inventory } = await supabase.from('inventory').select('*')

    if (!orders || !inventory) return

    for (const order of orders) {
      let canShip = true

      if (order.line_items && Array.isArray(order.line_items)) {
        for (const item of order.line_items) {
          const itemSku = item.sku
          if (!itemSku) {
            canShip = false
            continue
          }

          const stock = inventory.find((inv) => inv.sku === itemSku)
          if (!stock || stock.quantity < (item.quantity || 1)) {
            canShip = false
            break
          }
        }
      }

      // Update order
      await supabase.from('orders').update({ can_ship: canShip }).eq('id', order.id)
    }
  } catch (error) {
    console.error('Error updating order shippability:', error)
  }
}
