import { NextResponse } from 'next/server'
import supabase from '@/lib/supabase'
import axios from 'axios'

export const dynamic = 'force-dynamic'

// Shiprocket login and get token
async function getShiprocketToken(accountNumber: number) {
  const email =
    accountNumber === 1 ? process.env.SHIPROCKET_1_EMAIL : process.env.SHIPROCKET_2_EMAIL
  const password =
    accountNumber === 1 ? process.env.SHIPROCKET_1_PASSWORD : process.env.SHIPROCKET_2_PASSWORD

  try {
    const response = await axios.post('https://apiv2.shiprocket.in/v1/external/auth/login', {
      email,
      password,
    })

    return response.data.token
  } catch (error: any) {
    console.error(`Error logging into Shiprocket account ${accountNumber}:`, error.message)
    throw error
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { orderIds } = body

    if (!orderIds || orderIds.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: 'No orders provided',
        },
        { status: 400 }
      )
    }

    // Get orders from database
    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select('*')
      .in('id', orderIds)

    if (ordersError || !orders) {
      throw new Error('Error fetching orders')
    }

    // Get priorities
    const { data: priorities } = await supabase
      .from('priorities')
      .select('*')
      .order('priority_order', { ascending: true })

    // Sort orders by priority
    const sortedOrders = sortOrdersByPriority(orders, priorities || [])

    let shipped = 0
    const results = []

    for (const order of sortedOrders) {
      try {
        // Determine Shiprocket account
        const accountNumber = order.shiprocket_account || 1

        // Get Shiprocket token
        const token = await getShiprocketToken(accountNumber)

        // Create shipment in Shiprocket
        const shipmentData = {
          order_id: order.order_number,
          order_date: order.created_at,
          pickup_location: 'Primary',
          billing_customer_name: order.customer_name,
          billing_address: order.shipping_address?.address1 || '',
          billing_city: order.shipping_address?.city || '',
          billing_pincode: order.shipping_address?.zip || '',
          billing_state: order.shipping_address?.province || '',
          billing_country: order.shipping_address?.country || 'India',
          billing_email: order.customer_email || '',
          billing_phone: order.shipping_address?.phone || '9999999999',
          shipping_is_billing: true,
          order_items: (order.line_items || []).map((item: any) => ({
            name: item.name,
            sku: item.sku,
            units: item.quantity,
            selling_price: item.price,
          })),
          payment_method: order.payment_method?.includes('COD') ? 'COD' : 'Prepaid',
          sub_total: order.total_price,
          length: 10,
          breadth: 10,
          height: 10,
          weight: 0.5,
        }

        const response = await axios.post(
          'https://apiv2.shiprocket.in/v1/external/orders/create/adhoc',
          shipmentData,
          {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
          }
        )

        if (response.data.order_id) {
          // Update order status
          await supabase
            .from('orders')
            .update({
              status: 'shipped',
              updated_at: new Date().toISOString(),
            })
            .eq('id', order.id)

          // Save shipping history
          await supabase.from('shipping_history').insert({
            order_id: order.id,
            shiprocket_account: accountNumber,
            awb_number: response.data.awb_code || null,
            courier_name: response.data.courier_name || null,
            status: 'shipped',
          })

          shipped++
          results.push({
            order_number: order.order_number,
            success: true,
          })
        }
      } catch (error: any) {
        console.error(`Error shipping order ${order.order_number}:`, error.message)
        results.push({
          order_number: order.order_number,
          success: false,
          error: error.message,
        })
      }
    }

    return NextResponse.json({
      success: true,
      message: `Shipped ${shipped} out of ${orderIds.length} orders`,
      shipped,
      results,
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    )
  }
}

function sortOrdersByPriority(orders: any[], priorities: any[]) {
  return orders.sort((a, b) => {
    // Sort by location priority
    const locationPriorities = priorities.filter((p) => p.priority_type === 'location')
    const aLocationPriority = locationPriorities.findIndex(
      (p) => p.priority_value === a.shipping_address?.city
    )
    const bLocationPriority = locationPriorities.findIndex(
      (p) => p.priority_value === b.shipping_address?.city
    )

    if (aLocationPriority !== bLocationPriority) {
      return aLocationPriority - bLocationPriority
    }

    // Sort by payment method priority
    const paymentPriorities = priorities.filter((p) => p.priority_type === 'payment')
    const aPaymentPriority = paymentPriorities.findIndex((p) =>
      a.payment_method?.includes(p.priority_value)
    )
    const bPaymentPriority = paymentPriorities.findIndex((p) =>
      b.payment_method?.includes(p.priority_value)
    )

    return aPaymentPriority - bPaymentPriority
  })
}
