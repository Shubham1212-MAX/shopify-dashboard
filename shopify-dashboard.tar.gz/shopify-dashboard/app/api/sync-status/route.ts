import { NextResponse } from 'next/server'
import supabase from '@/lib/supabase'
import axios from 'axios'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  try {
    console.log('🔄 Starting status sync...')

    // Get all orders
    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select('*')
      .limit(100)

    if (ordersError) {
      throw new Error(`Database error: ${ordersError.message}`)
    }

    if (!orders || orders.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'No orders to sync',
      })
    }

    // Get stores
    const { data: stores } = await supabase.from('stores').select('*')

    let updated = 0

    for (const order of orders) {
      const store = stores?.find((s) => s.id === order.store_id)
      if (!store) continue

      try {
        // Fetch latest order status from Shopify
        const response = await axios.get(
          `https://${store.shopify_url}/admin/api/2024-01/orders/${order.shopify_order_id}.json`,
          {
            headers: {
              'X-Shopify-Access-Token': store.access_token,
            },
          }
        )

        const shopifyOrder = response.data.order
        const newStatus = shopifyOrder.fulfillment_status || shopifyOrder.financial_status || 'pending'

        // Update if status changed
        if (newStatus !== order.status) {
          await supabase
            .from('orders')
            .update({
              status: newStatus,
              updated_at: new Date().toISOString(),
            })
            .eq('id', order.id)

          updated++
        }
      } catch (error: any) {
        console.error(`Error updating order ${order.order_number}:`, error.message)
      }
    }

    console.log(`✅ Status sync completed! Updated ${updated} orders`)

    return NextResponse.json({
      success: true,
      message: `Updated ${updated} order statuses`,
      updated,
    })
  } catch (error: any) {
    console.error('❌ Status sync error:', error)
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    )
  }
}

export async function GET(request: Request) {
  return POST(request)
}
